package com.payroll_testing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PayrollTestingApplication {

	public static void main(String[] args) {
		SpringApplication.run(PayrollTestingApplication.class, args);
	}

}
